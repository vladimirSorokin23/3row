//
//  ConfigKeys.swift
//  FruttyTreats
//
//

import Foundation

enum ConfigKeys {
    static let availableLink = "AVAILABLE_LINK"
    static let remoteLink = "remote_link"
}
