//
//  UserDefaultKeys.swift
//  FruttyTreats
//
//

import Foundation

enum UserDefaultsKeys {
    static let stat = "STATISTICS"
}
